export interface CustomerDetails {
    firstname: string;
    middlename: string;
    lastname: string;
    companycode: string;
    mobilecode: string;
    mobileno: string;
    emailid: string;
    cr_dt: Date;
    cr_id: string;
    up_dt: Date;
    up_id: string;
  }