import { CustomerRoutingModule } from './customer-routing.module';
import { CustomerComponent } from './customer.component';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatSortModule} from '@angular/material/sort';


@NgModule({
  declarations: [CustomerComponent],
  imports: [  
      CustomerRoutingModule,
      MatTableModule,
      MatPaginatorModule,
      MatSortModule,
  ],
  providers: [],
  bootstrap: [CustomerComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class CustomerModule {}