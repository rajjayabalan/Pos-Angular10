import { Injectable } from '@angular/core';
import { CrudService } from 'src/app/core/services/http/crud.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { StorageService } from '../../core/services/storage/storage.service';
import { StorageKey } from '../../core/services/storage/storage.model';
import {CustomerDetails} from '../customer/CustomerDetails';

const { AUTH_TOKEN } = StorageKey;
const { CUSTOMER_FETCH } = StorageKey;

@Injectable({
  providedIn: 'root'
})

export class CustomerService extends CrudService{

  endpoint = 'auth';
  token: string;
  redirectUrl: string;

  constructor(http: HttpClient, private storage: StorageService) {
    super(http);
    this.token = this.storage.read(AUTH_TOKEN) || '';
  }

 /* customerDetails : getCustomerDetails() {
    let headers = new Headers({ 'Content-Type': 'application/json' });
    return this.get<any[]>(CUSTOMER_FETCH,'','');
  }*/

 
  public getCustomerDetails(){
    return this.get<CustomerDetails[]>(CUSTOMER_FETCH,'','');
  }
  

}
