export enum StorageKey {
    AUTH_TOKEN = 'AUTH_TOKEN',
    AUTH_LOGIN = 'api/auth/signin',
    CUSTOMER_FETCH = 'customer/fetchingCustomerDetails',
}
