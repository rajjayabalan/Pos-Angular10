import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment';

export abstract class CrudService<T = any> {
    abstract endpoint;
    url = environment.apiUrl;

    protected constructor(protected http: HttpClient) {}

    public async get<G>(serviceName:string,request: string,body): Promise<G | null> {
        let response = null;
        try {
            this.endpoint =serviceName;
            response = await this.http
                .get<T>(`${this.url}/${this.endpoint}/${request}`,body)
                .toPromise();
        } catch (error) {
            response = this.errorHandler('GET', error);
        }
        return response;
    }

    public async getList(): Promise<T[] | null> {
        return this.get<T[]>('','list','');
    }

    public async getById(id: number | string): Promise<T | null> {
        return this.get<T>('','' + id,'');
    }

    public async post(serviceName:string,body): Promise<any> {
        let response = null;
        try {
            this.endpoint =serviceName;
            response = await this.http
                .post(`${this.url}/${this.endpoint}`, body)
                .toPromise();
        } catch (error) {
            response = this.errorHandler('POST', error);
        }
        return response;
    }

    public async deleteById(id: number | string): Promise<any> {
        let response = null;
        try {
            response = await this.http
                .delete(`${this.url}/${this.endpoint}/${id}`)
                .toPromise();
        } catch (error) {
            response = this.errorHandler('DELETE', error);
        }
        return response;
    }

    public errorHandler(
        method: string,
        error: HttpErrorResponse,
    ): Promise<never> {
        console.error(
            `Error occurred during ${method} ${this.url}/${this.endpoint}`,
            error,
        );
        return Promise.reject(error);
    }
}
