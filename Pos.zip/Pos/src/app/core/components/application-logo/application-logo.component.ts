import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-application-logo',
  templateUrl: './application-logo.component.html',
  styleUrls: ['./application-logo.component.scss']
})
export class ApplicationLogoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
