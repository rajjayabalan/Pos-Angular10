import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApplicationLogoComponent } from './application-logo.component';

@NgModule({
    declarations: [ApplicationLogoComponent],
    exports: [ApplicationLogoComponent],
    imports: [CommonModule],
})
export class ApplicationLogoModule {}
